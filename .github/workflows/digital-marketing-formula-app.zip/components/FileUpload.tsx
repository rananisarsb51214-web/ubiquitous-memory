import React, { useState, useCallback, useRef, useEffect } from 'react';
import { Button } from './Button';
import { LoadingSpinner } from './LoadingSpinner';

interface FileUploadProps {
  id: string;
  label: string;
  accept: string; // e.g., "image/*", "audio/*", "video/*"
  onFileChange: (file: File | null) => void;
  isLoading?: boolean;
  error?: string | null;
  currentFile?: File | null; // Allow parent to control the current file state for resetting
  filePreviewUrl?: string | null; // For displaying a generated image/video as preview
}

export const FileUpload: React.FC<FileUploadProps> = ({
  id,
  label,
  accept,
  onFileChange,
  isLoading,
  error,
  currentFile,
  filePreviewUrl,
}) => {
  const [preview, setPreview] = useState<string | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    if (currentFile) {
      const objectUrl = URL.createObjectURL(currentFile);
      setPreview(objectUrl);
      return () => URL.revokeObjectURL(objectUrl);
    } else {
      setPreview(null);
    }
  }, [currentFile]);

  const handleFileSelect = useCallback((e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0] || null;
    onFileChange(file);
    if (file) {
      const objectUrl = URL.createObjectURL(file);
      setPreview(objectUrl);
      // Clean up the object URL when the component unmounts or file changes
      return () => URL.revokeObjectURL(objectUrl);
    } else {
      setPreview(null);
    }
  }, [onFileChange]);

  const handleClearFile = useCallback(() => {
    if (fileInputRef.current) {
      fileInputRef.current.value = ''; // Clear the input visually
    }
    setPreview(null);
    onFileChange(null);
  }, [onFileChange]);

  const renderPreview = () => {
    if (filePreviewUrl) {
      const isImage = accept.startsWith('image/');
      const isVideo = accept.startsWith('video/');
      return (
        <div className="mt-4 flex flex-col items-center">
          {isImage && (
            <img src={filePreviewUrl} alt="Generated Preview" className="max-w-full h-auto max-h-64 rounded-lg shadow-md border dark:border-gray-600" />
          )}
          {isVideo && (
            <video src={filePreviewUrl} controls className="max-w-full h-auto max-h-64 rounded-lg shadow-md border dark:border-gray-600" />
          )}
          <p className="text-sm text-gray-600 dark:text-gray-300 mt-2">Generated output</p>
        </div>
      );
    } else if (preview) {
      const isImage = accept.startsWith('image/');
      const isVideo = accept.startsWith('video/');
      return (
        <div className="mt-4 flex flex-col items-center">
          {isImage && (
            <img src={preview} alt="File Preview" className="max-w-full h-auto max-h-64 rounded-lg shadow-md border dark:border-gray-600" />
          )}
          {isVideo && (
            <video src={preview} controls className="max-w-full h-auto max-h-64 rounded-lg shadow-md border dark:border-gray-600" />
          )}
          {!isImage && !isVideo && (
            <p className="text-sm text-gray-600 dark:text-gray-300 mt-2">Selected: {currentFile?.name}</p>
          )}
        </div>
      );
    }
    return null;
  };

  return (
    <div className="w-full bg-white dark:bg-gray-700 p-6 rounded-lg shadow-md border border-gray-200 dark:border-gray-600">
      <label htmlFor={id} className="block text-lg font-medium text-gray-800 dark:text-gray-100 mb-2">
        {label}
      </label>
      <input
        ref={fileInputRef}
        type="file"
        id={id}
        accept={accept}
        onChange={handleFileSelect}
        className="block w-full text-sm text-gray-900 dark:text-gray-50
                   file:mr-4 file:py-2 file:px-4
                   file:rounded-full file:border-0
                   file:text-sm file:font-semibold
                   file:bg-purple-50 file:text-purple-700
                   hover:file:bg-purple-100 dark:file:bg-gray-600 dark:file:text-purple-300
                   dark:hover:file:bg-gray-500
                   mb-4"
        disabled={isLoading}
      />
      {error && (
        <p className="mt-1 text-sm text-red-600 dark:text-red-400">{error}</p>
      )}

      {renderPreview()}

      {(currentFile || filePreviewUrl) && (
        <div className="mt-4 text-right">
          <Button
            type="button"
            onClick={handleClearFile}
            variant="ghost"
            disabled={isLoading}
            className="text-red-500 hover:text-red-700 dark:text-red-400 dark:hover:text-red-600"
          >
            Clear File
          </Button>
        </div>
      )}
    </div>
  );
};
