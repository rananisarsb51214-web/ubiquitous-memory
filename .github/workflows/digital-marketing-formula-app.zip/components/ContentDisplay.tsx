import React, { useState, useCallback } from 'react';
import { Button } from './Button';

interface ContentDisplayProps {
  content: string;
  onBack: () => void; // For generating new content for the same formula
  onBackToMain: () => void; // For going back to the main feature selection
}

export const ContentDisplay: React.FC<ContentDisplayProps> = ({ content, onBack, onBackToMain }) => {
  const [copySuccess, setCopySuccess] = useState<boolean>(false);

  const handleCopy = useCallback(async () => {
    try {
      await navigator.clipboard.writeText(content);
      setCopySuccess(true);
      setTimeout(() => setCopySuccess(false), 2000); // Reset success message after 2 seconds
    } catch (err) {
      console.error('Failed to copy text: ', err);
      // Optionally show an error message
    }
  }, [content]);

  return (
    <div className="bg-gray-50 dark:bg-gray-900 p-6 rounded-lg shadow-inner border border-gray-200 dark:border-gray-700">
      <h3 className="text-xl font-bold text-gray-800 dark:text-gray-100 mb-4 text-center">Generated Content:</h3>
      <div className="relative mb-6">
        <textarea
          readOnly
          value={content}
          rows={10}
          className="w-full p-4 border border-gray-300 dark:border-gray-600 rounded-md bg-white dark:bg-gray-800 text-gray-900 dark:text-gray-50 resize-y focus:outline-none"
        />
        {copySuccess && (
          <span className="absolute bottom-2 right-2 px-3 py-1 bg-green-500 text-white text-xs rounded-full">
            Copied!
          </span>
        )}
      </div>

      <div className="flex flex-col sm:flex-row justify-end space-y-3 sm:space-y-0 sm:space-x-3 mt-4">
        <Button
          type="button"
          onClick={handleCopy}
          variant="primary"
          className="w-full sm:w-auto"
        >
          Copy to Clipboard
        </Button>
        <Button
          type="button"
          onClick={onBack}
          variant="secondary"
          className="w-full sm:w-auto"
        >
          Generate New
        </Button>
        <Button
          type="button"
          onClick={onBackToMain}
          variant="outline"
          className="w-full sm:w-auto"
        >
          Back to Tools
        </Button>
      </div>
    </div>
  );
};
