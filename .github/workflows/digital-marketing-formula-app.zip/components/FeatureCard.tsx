import React from 'react';
import { FeatureCardProps } from '../types';
import { Button } from './Button';

interface FeatureCardDisplayProps {
  feature: FeatureCardProps;
  onSelect: (feature: FeatureCardProps) => void;
}

export const FeatureCard: React.FC<FeatureCardDisplayProps> = ({ feature, onSelect }) => {
  return (
    <div className="bg-white dark:bg-gray-700 rounded-lg shadow-md p-6 flex flex-col items-center text-center hover:shadow-lg transition-shadow duration-300 border border-gray-200 dark:border-gray-600">
      <div className="text-5xl mb-4" role="img" aria-label={feature.name}>
        {feature.icon}
      </div>
      <h3 className="text-xl font-bold text-gray-800 dark:text-gray-100 mb-2">{feature.name}</h3>
      <p className="text-gray-600 dark:text-gray-300 mb-4 flex-grow">{feature.description}</p>
      <Button onClick={() => onSelect(feature)} className="w-full">
        Open Tool
      </Button>
    </div>
  );
};
