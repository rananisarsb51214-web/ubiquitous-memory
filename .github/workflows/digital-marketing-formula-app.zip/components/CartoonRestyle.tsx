import React, { useState, useCallback } from 'react';
import { Button } from './Button';
import { FileUpload } from './FileUpload';
import { editImage } from '../services/geminiService';
import { blobToBase64 } from '../utils/audioUtils';

interface CartoonRestyleProps {
  onBack: () => void;
}

export const CartoonRestyle: React.FC<CartoonRestyleProps> = ({ onBack }) => {
  const [imageFile, setImageFile] = useState<File | null>(null);
  const [restyledImageUrl, setRestyledImageUrl] = useState<string | null>(null);
  const [isLoading, setIsLoading] = useState<boolean>(false);
  const [error, setError] = useState<string | null>(null);

  const handleFileChange = useCallback((file: File | null) => {
    setImageFile(file);
    setRestyledImageUrl(null); // Clear restyled image if source changes
  }, []);

  const handleSubmit = useCallback(async (e: React.FormEvent) => {
    e.preventDefault();
    if (!imageFile) {
      setError("Please upload an image to restyle.");
      return;
    }

    setIsLoading(true);
    setError(null);
    setRestyledImageUrl(null);

    try {
      const base64Image = await blobToBase64(imageFile);
      const prompt = "restyle this image in a vibrant and playful cartoon art style.";
      const imageUrl = await editImage(base64Image, imageFile.type, prompt);
      setRestyledImageUrl(imageUrl);
    } catch (err: any) {
      console.error("Error restyling image:", err);
      setError(err.message || "Failed to restyle image. Please try again.");
    } finally {
      setIsLoading(false);
    }
  }, [imageFile]);

  return (
    <div className="space-y-6">
      <h2 className="text-2xl sm:text-3xl font-bold text-gray-800 dark:text-gray-100 text-center mb-6">
        Cartoon Style Restyler
      </h2>
      <p className="text-gray-600 dark:text-gray-300 text-center">
        Upload an image and Gemini will transform it into a fun cartoon style.
      </p>

      <form onSubmit={handleSubmit} className="space-y-4 p-4 border border-gray-200 dark:border-gray-700 rounded-lg shadow-sm">
        <FileUpload
          id="upload-image-cartoon"
          label="Upload Image"
          accept="image/*"
          onFileChange={handleFileChange}
          isLoading={isLoading}
          currentFile={imageFile}
        />

        {error && (
          <div className="bg-red-100 dark:bg-red-900 border border-red-400 text-red-700 dark:text-red-300 px-4 py-3 rounded relative" role="alert">
            <strong className="font-bold">Error: </strong>
            <span className="block sm:inline">{error}</span>
          </div>
        )}

        <div className="flex flex-col sm:flex-row justify-end space-y-3 sm:space-y-0 sm:space-x-3 mt-8">
          <Button
            type="button"
            onClick={onBack}
            variant="secondary"
            disabled={isLoading}
            className="w-full sm:w-auto"
          >
            Back to Tools
          </Button>
          <Button
            type="submit"
            isLoading={isLoading}
            disabled={isLoading}
            className="w-full sm:w-auto"
          >
            Apply Cartoon Style
          </Button>
        </div>
      </form>

      {restyledImageUrl && (
        <div className="mt-8 p-4 border border-gray-200 dark:border-gray-700 rounded-lg shadow-md text-center">
          <h3 className="text-xl font-bold text-gray-800 dark:text-gray-100 mb-4">Restyled Image:</h3>
          <img src={restyledImageUrl} alt="Restyled Cartoon" className="max-w-full h-auto mx-auto rounded-lg shadow-lg" />
          <div className="mt-4">
            <Button
              onClick={() => {
                const link = document.createElement('a');
                link.href = restyledImageUrl;
                link.download = 'cartoon-image.png'; // Or infer type
                document.body.appendChild(link);
                link.click();
                document.body.removeChild(link);
              }}
              variant="primary"
            >
              Download Image
            </Button>
          </div>
        </div>
      )}
    </div>
  );
};