import React, { useState, useCallback } from 'react';
import { Input } from './Input';
import { Select } from './Select';
import { Button } from './Button';
import { LoadingSpinner } from './LoadingSpinner';
import { ImageAspectRatio } from '../types';
import { generateImage } from '../services/geminiService';

interface ImageGeneratorProps {
  onBack: () => void;
}

export const ImageGenerator: React.FC<ImageGeneratorProps> = ({ onBack }) => {
  const [prompt, setPrompt] = useState<string>('');
  const [aspectRatio, setAspectRatio] = useState<ImageAspectRatio>(ImageAspectRatio._1_1);
  const [generatedImageUrl, setGeneratedImageUrl] = useState<string | null>(null);
  const [isLoading, setIsLoading] = useState<boolean>(false);
  const [error, setError] = useState<string | null>(null);

  const handleSubmit = useCallback(async (e: React.FormEvent) => {
    e.preventDefault();
    if (!prompt.trim()) {
      setError("Please enter a prompt to generate an image.");
      return;
    }

    setIsLoading(true);
    setError(null);
    setGeneratedImageUrl(null);

    try {
      const imageUrl = await generateImage(prompt, aspectRatio);
      setGeneratedImageUrl(imageUrl);
    } catch (err: any) {
      console.error("Error generating image:", err);
      setError(err.message || "Failed to generate image. Please try again.");
    } finally {
      setIsLoading(false);
    }
  }, [prompt, aspectRatio]);

  return (
    <div className="space-y-6">
      <h2 className="text-2xl sm:text-3xl font-bold text-gray-800 dark:text-gray-100 text-center mb-6">
        AI Image Generator
      </h2>
      <p className="text-gray-600 dark:text-gray-300 text-center">
        Create stunning images from text prompts using Gemini. Requires a selected API key for billing.
      </p>

      <form onSubmit={handleSubmit} className="space-y-4 p-4 border border-gray-200 dark:border-gray-700 rounded-lg shadow-sm">
        <Input
          id="image-prompt"
          label="Image Prompt"
          type="text"
          placeholder="e.g., A majestic lion with a golden mane in a futuristic city"
          value={prompt}
          onChange={(e) => setPrompt(e.target.value)}
          required
          disabled={isLoading}
        />
        <Select
          id="aspect-ratio"
          label="Aspect Ratio"
          options={Object.values(ImageAspectRatio)}
          value={aspectRatio}
          onChange={(e) => setAspectRatio(e.target.value as ImageAspectRatio)}
          disabled={isLoading}
        />

        {error && (
          <div className="bg-red-100 dark:bg-red-900 border border-red-400 text-red-700 dark:text-red-300 px-4 py-3 rounded relative" role="alert">
            <strong className="font-bold">Error: </strong>
            <span className="block sm:inline">{error}</span>
          </div>
        )}

        <div className="flex flex-col sm:flex-row justify-end space-y-3 sm:space-y-0 sm:space-x-3 mt-8">
          <Button
            type="button"
            onClick={onBack}
            variant="secondary"
            disabled={isLoading}
            className="w-full sm:w-auto"
          >
            Back to Tools
          </Button>
          <Button
            type="submit"
            isLoading={isLoading}
            disabled={isLoading}
            className="w-full sm:w-auto"
          >
            Generate Image
          </Button>
        </div>
      </form>

      {generatedImageUrl && (
        <div className="mt-8 p-4 border border-gray-200 dark:border-gray-700 rounded-lg shadow-md text-center">
          <h3 className="text-xl font-bold text-gray-800 dark:text-gray-100 mb-4">Generated Image:</h3>
          <img src={generatedImageUrl} alt="Generated" className="max-w-full h-auto mx-auto rounded-lg shadow-lg" />
          <div className="mt-4">
            <Button
              onClick={() => {
                const link = document.createElement('a');
                link.href = generatedImageUrl;
                link.download = 'generated-image.png'; // Or infer type from base64 string
                document.body.appendChild(link);
                link.click();
                document.body.removeChild(link);
              }}
              variant="primary"
            >
              Download Image
            </Button>
          </div>
        </div>
      )}
    </div>
  );
};
