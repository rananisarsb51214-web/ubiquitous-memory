import React from 'react';

interface SelectProps extends React.SelectHTMLAttributes<HTMLSelectElement> {
  label?: string;
  id: string;
  options: string[];
  error?: string;
  defaultOptionLabel?: string;
}

export const Select: React.FC<SelectProps> = ({
  label,
  id,
  options,
  error,
  className,
  defaultOptionLabel = 'Select an option',
  ...props
}) => {
  return (
    <div className="w-full">
      {label && (
        <label htmlFor={id} className="block text-sm font-medium text-gray-700 dark:text-gray-200 mb-1">
          {label}
        </label>
      )}
      <select
        id={id}
        className={`block w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-md shadow-sm
          focus:outline-none focus:ring-purple-500 focus:border-purple-500 sm:text-sm
          bg-white dark:bg-gray-700 text-gray-900 dark:text-gray-50
          ${error ? 'border-red-500 focus:ring-red-500 focus:border-red-500' : ''}
          ${className || ''}`}
        {...props}
      >
        <option value="">{defaultOptionLabel}</option>
        {options.map((option) => (
          <option key={option} value={option}>
            {option}
          </option>
        ))}
      </select>
      {error && (
        <p className="mt-1 text-sm text-red-600 dark:text-red-400">{error}</p>
      )}
    </div>
  );
};
