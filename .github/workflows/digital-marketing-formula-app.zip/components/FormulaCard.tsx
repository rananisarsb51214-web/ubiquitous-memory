import React from 'react';
import { FeatureCardProps } from '../types'; // Fix: Changed MarketingFormula to FeatureCardProps
import { Button } from './Button';

interface FormulaCardProps {
  formula: FeatureCardProps; // Fix: Changed MarketingFormula to FeatureCardProps
  onSelect: (formula: FeatureCardProps) => void; // Fix: Changed MarketingFormula to FeatureCardProps
}

export const FormulaCard: React.FC<FormulaCardProps> = ({ formula, onSelect }) => {
  return (
    <div className="bg-white dark:bg-gray-700 rounded-lg shadow-md p-6 flex flex-col items-center text-center hover:shadow-lg transition-shadow duration-300 border border-gray-200 dark:border-gray-600">
      <div className="text-5xl mb-4" role="img" aria-label={formula.name}>
        {formula.icon}
      </div>
      <h3 className="text-xl font-bold text-gray-800 dark:text-gray-100 mb-2">{formula.name}</h3>
      <p className="text-gray-600 dark:text-gray-300 mb-4 flex-grow">{formula.description}</p>
      <Button onClick={() => onSelect(formula)} className="w-full">
        Select Formula
      </Button>
    </div>
  );
};