import React, { useState, useCallback } from 'react';
import { FileUpload } from './FileUpload';
import { TextArea } from './TextArea';
import { Button } from './Button';
import { analyzeVideo } from '../services/geminiService';

interface VideoAnalyzerProps {
  onBack: () => void;
}

export const VideoAnalyzer: React.FC<VideoAnalyzerProps> = ({ onBack }) => {
  const [videoFile, setVideoFile] = useState<File | null>(null);
  const [analysisPrompt, setAnalysisPrompt] = useState<string>('');
  const [analysisResult, setAnalysisResult] = useState<string>('');
  const [isLoading, setIsLoading] = useState<boolean>(false);
  const [error, setError] = useState<string | null>(null);

  const handleFileChange = useCallback((file: File | null) => {
    setVideoFile(file);
    setAnalysisResult(''); // Clear previous result
  }, []);

  const handleSubmit = useCallback(async (e: React.FormEvent) => {
    e.preventDefault();
    if (!videoFile) {
      setError("Please upload a video file for analysis.");
      return;
    }
    if (!analysisPrompt.trim()) {
      setError("Please enter a prompt for video analysis.");
      return;
    }

    setIsLoading(true);
    setError(null);
    setAnalysisResult('');

    try {
      const result = await analyzeVideo(videoFile, analysisPrompt);
      setAnalysisResult(result);
    } catch (err: any) {
      console.error("Error analyzing video:", err);
      setError(err.message || "Failed to analyze video. Please try again.");
    } finally {
      setIsLoading(false);
    }
  }, [videoFile, analysisPrompt]);

  return (
    <div className="space-y-6">
      <h2 className="text-2xl sm:text-3xl font-bold text-gray-800 dark:text-gray-100 text-center mb-6">
        AI Video Analyzer
      </h2>
      <p className="text-gray-600 dark:text-gray-300 text-center">
        Upload a video and ask Gemini to analyze its content for key information.
        Requires a selected API key for billing.
      </p>

      <form onSubmit={handleSubmit} className="space-y-4 p-4 border border-gray-200 dark:border-gray-700 rounded-lg shadow-sm">
        <FileUpload
          id="upload-video"
          label="Upload Video File"
          accept="video/*"
          onFileChange={handleFileChange}
          isLoading={isLoading}
          currentFile={videoFile}
        />
        <TextArea
          id="analysis-prompt"
          label="What do you want to analyze in this video?"
          placeholder="e.g., Summarize the main events, Describe the objects present, Identify the sentiment of the speakers."
          value={analysisPrompt}
          onChange={(e) => setAnalysisPrompt(e.target.value)}
          required
          disabled={isLoading}
        />

        {error && (
          <div className="bg-red-100 dark:bg-red-900 border border-red-400 text-red-700 dark:text-red-300 px-4 py-3 rounded relative" role="alert">
            <strong className="font-bold">Error: </strong>
            <span className="block sm:inline">{error}</span>
          </div>
        )}

        <div className="flex flex-col sm:flex-row justify-end space-y-3 sm:space-y-0 sm:space-x-3 mt-8">
          <Button
            type="button"
            onClick={onBack}
            variant="secondary"
            disabled={isLoading}
            className="w-full sm:w-auto"
          >
            Back to Tools
          </Button>
          <Button
            type="submit"
            isLoading={isLoading}
            disabled={isLoading}
            className="w-full sm:w-auto"
          >
            Analyze Video
          </Button>
        </div>
      </form>

      {analysisResult && (
        <div className="mt-8 p-4 border border-gray-200 dark:border-gray-700 rounded-lg shadow-md">
          <h3 className="text-xl font-bold text-gray-800 dark:text-gray-100 mb-4 text-center">Analysis Result:</h3>
          <TextArea
            id="analysis-output"
            label="Video Analysis"
            value={analysisResult}
            readOnly
            rows={10}
            className="bg-gray-100 dark:bg-gray-800 cursor-default"
          />
        </div>
      )}
    </div>
  );
};
