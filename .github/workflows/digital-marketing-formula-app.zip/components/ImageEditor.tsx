import React, { useState, useCallback } from 'react';
import { Input } from './Input';
import { Button } from './Button';
import { FileUpload } from './FileUpload';
import { editImage } from '../services/geminiService';
import { blobToBase64 } from '../utils/audioUtils';

interface ImageEditorProps {
  onBack: () => void;
}

export const ImageEditor: React.FC<ImageEditorProps> = ({ onBack }) => {
  const [imageFile, setImageFile] = useState<File | null>(null);
  const [editPrompt, setEditPrompt] = useState<string>('');
  const [editedImageUrl, setEditedImageUrl] = useState<string | null>(null);
  const [isLoading, setIsLoading] = useState<boolean>(false);
  const [error, setError] = useState<string | null>(null);

  const handleFileChange = useCallback((file: File | null) => {
    setImageFile(file);
    setEditedImageUrl(null); // Clear edited image if source changes
  }, []);

  const handleSubmit = useCallback(async (e: React.FormEvent) => {
    e.preventDefault();
    if (!imageFile) {
      setError("Please upload an image to edit.");
      return;
    }
    if (!editPrompt.trim()) {
      setError("Please enter an edit instruction.");
      return;
    }

    setIsLoading(true);
    setError(null);
    setEditedImageUrl(null);

    try {
      const base64Image = await blobToBase64(imageFile);
      const imageUrl = await editImage(base64Image, imageFile.type, editPrompt);
      setEditedImageUrl(imageUrl);
    } catch (err: any) {
      console.error("Error editing image:", err);
      setError(err.message || "Failed to edit image. Please try again.");
    } finally {
      setIsLoading(false);
    }
  }, [imageFile, editPrompt]);

  return (
    <div className="space-y-6">
      <h2 className="text-2xl sm:text-3xl font-bold text-gray-800 dark:text-gray-100 text-center mb-6">
        AI Image Editor
      </h2>
      <p className="text-gray-600 dark:text-gray-300 text-center">
        Upload an image and tell Gemini how to edit it.
      </p>

      <form onSubmit={handleSubmit} className="space-y-4 p-4 border border-gray-200 dark:border-gray-700 rounded-lg shadow-sm">
        <FileUpload
          id="upload-image-edit"
          label="Upload Image"
          accept="image/*"
          onFileChange={handleFileChange}
          isLoading={isLoading}
          currentFile={imageFile}
        />
        <Input
          id="edit-prompt"
          label="Edit Instruction"
          type="text"
          placeholder="e.g., Add a retro filter, Remove the person in the background"
          value={editPrompt}
          onChange={(e) => setEditPrompt(e.target.value)}
          required
          disabled={isLoading}
        />

        {error && (
          <div className="bg-red-100 dark:bg-red-900 border border-red-400 text-red-700 dark:text-red-300 px-4 py-3 rounded relative" role="alert">
            <strong className="font-bold">Error: </strong>
            <span className="block sm:inline">{error}</span>
          </div>
        )}

        <div className="flex flex-col sm:flex-row justify-end space-y-3 sm:space-y-0 sm:space-x-3 mt-8">
          <Button
            type="button"
            onClick={onBack}
            variant="secondary"
            disabled={isLoading}
            className="w-full sm:w-auto"
          >
            Back to Tools
          </Button>
          <Button
            type="submit"
            isLoading={isLoading}
            disabled={isLoading}
            className="w-full sm:w-auto"
          >
            Edit Image
          </Button>
        </div>
      </form>

      {editedImageUrl && (
        <div className="mt-8 p-4 border border-gray-200 dark:border-gray-700 rounded-lg shadow-md text-center">
          <h3 className="text-xl font-bold text-gray-800 dark:text-gray-100 mb-4">Edited Image:</h3>
          <img src={editedImageUrl} alt="Edited" className="max-w-full h-auto mx-auto rounded-lg shadow-lg" />
          <div className="mt-4">
            <Button
              onClick={() => {
                const link = document.createElement('a');
                link.href = editedImageUrl;
                link.download = 'edited-image.png'; // Or infer type
                document.body.appendChild(link);
                link.click();
                document.body.removeChild(link);
              }}
              variant="primary"
            >
              Download Edited Image
            </Button>
          </div>
        </div>
      )}
    </div>
  );
};
