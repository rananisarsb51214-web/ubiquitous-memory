import React, { useState, useCallback, useRef, useEffect } from 'react';
import { TextArea } from './TextArea';
import { Button } from './Button';
import { generateSpeech } from '../services/geminiService';
import { decodeAudioData } from '../utils/audioUtils';

interface SpeechGeneratorProps {
  onBack: () => void;
}

export const SpeechGenerator: React.FC<SpeechGeneratorProps> = ({ onBack }) => {
  const [text, setText] = useState<string>('');
  const [isLoading, setIsLoading] = useState<boolean>(false);
  const [error, setError] = useState<string | null>(null);
  const audioContextRef = useRef<AudioContext | null>(null);
  const audioSourceRef = useRef<AudioBufferSourceNode | null>(null);

  const playAudio = useCallback(async (audioBuffer: AudioBuffer) => {
    // Stop any currently playing audio
    if (audioSourceRef.current) {
      audioSourceRef.current.stop();
      audioSourceRef.current.disconnect();
    }

    // Fix: Use type assertion for window.webkitAudioContext to resolve TypeScript error while adhering to guideline pattern.
    if (!audioContextRef.current) {
      audioContextRef.current = new (window.AudioContext || (window as any).webkitAudioContext)();
    }

    const source = audioContextRef.current.createBufferSource();
    source.buffer = audioBuffer;
    source.connect(audioContextRef.current.destination);
    source.start(0);
    audioSourceRef.current = source;
  }, []);

  const handleSubmit = useCallback(async (e: React.FormEvent) => {
    e.preventDefault();
    if (!text.trim()) {
      setError("Please enter text to convert to speech.");
      return;
    }

    setIsLoading(true);
    setError(null);

    try {
      const audioBuffer = await generateSpeech(text);
      await playAudio(audioBuffer);
    } catch (err: any) {
      console.error("Error generating speech:", err);
      setError(err.message || "Failed to generate speech. Please try again.");
    } finally {
      setIsLoading(false);
    }
  }, [text, playAudio]);

  // Clean up AudioContext on unmount
  React.useEffect(() => {
    return () => {
      if (audioSourceRef.current) {
        audioSourceRef.current.stop();
        audioSourceRef.current.disconnect();
      }
      if (audioContextRef.current) {
        audioContextRef.current.close();
      }
    };
  }, []);

  return (
    <div className="space-y-6">
      <h2 className="text-2xl sm:text-3xl font-bold text-gray-800 dark:text-gray-100 text-center mb-6">
        Text-to-Speech
      </h2>
      <p className="text-gray-600 dark:text-gray-300 text-center">
        Convert your text into natural-sounding speech using Gemini.
      </p>

      <form onSubmit={handleSubmit} className="space-y-4 p-4 border border-gray-200 dark:border-gray-700 rounded-lg shadow-sm">
        <TextArea
          id="tts-text"
          label="Text to Speak"
          placeholder="e.g., Hello, how can I help you today?"
          value={text}
          onChange={(e) => setText(e.target.value)}
          required
          disabled={isLoading}
        />

        {error && (
          <div className="bg-red-100 dark:bg-red-900 border border-red-400 text-red-700 dark:text-red-300 px-4 py-3 rounded relative" role="alert">
            <strong className="font-bold">Error: </strong>
            <span className="block sm:inline">{error}</span>
          </div>
        )}

        <div className="flex flex-col sm:flex-row justify-end space-y-3 sm:space-y-0 sm:space-x-3 mt-8">
          <Button
            type="button"
            onClick={onBack}
            variant="secondary"
            disabled={isLoading}
            className="w-full sm:w-auto"
          >
            Back to Tools
          </Button>
          <Button
            type="submit"
            isLoading={isLoading}
            disabled={isLoading}
            className="w-full sm:w-auto"
          >
            Generate & Play Speech
          </Button>
        </div>
      </form>

      {audioSourceRef.current && !isLoading && !error && (
        <div className="mt-8 p-4 border border-gray-200 dark:border-gray-700 rounded-lg shadow-md text-center">
          <h3 className="text-xl font-bold text-gray-800 dark:text-gray-100 mb-4">Speech Output:</h3>
          <audio controls src={URL.createObjectURL(new Blob([/* Provide actual audio blob if possible for download */]))} className="w-full max-w-md mx-auto" aria-label="Generated speech playback" />
          <p className="text-gray-600 dark:text-gray-300 text-sm mt-2">Audio is automatically played after generation.</p>
        </div>
      )}
    </div>
  );
};