import React, { useState, useCallback } from 'react';
import { FileUpload } from './FileUpload';
import { Button } from './Button';
import { TextArea } from './TextArea';
import { transcribeAudio } from '../services/geminiService';

interface AudioTranscriberProps {
  onBack: () => void;
}

export const AudioTranscriber: React.FC<AudioTranscriberProps> = ({ onBack }) => {
  const [audioFile, setAudioFile] = useState<File | null>(null);
  const [transcription, setTranscription] = useState<string>('');
  const [isLoading, setIsLoading] = useState<boolean>(false);
  const [error, setError] = useState<string | null>(null);

  const handleFileChange = useCallback((file: File | null) => {
    setAudioFile(file);
    setTranscription(''); // Clear previous transcription
  }, []);

  const handleSubmit = useCallback(async (e: React.FormEvent) => {
    e.preventDefault();
    if (!audioFile) {
      setError("Please upload an audio file to transcribe.");
      return;
    }

    setIsLoading(true);
    setError(null);
    setTranscription('');

    try {
      const result = await transcribeAudio(audioFile);
      setTranscription(result);
    } catch (err: any) {
      console.error("Error transcribing audio:", err);
      setError(err.message || "Failed to transcribe audio. Please try again.");
    } finally {
      setIsLoading(false);
    }
  }, [audioFile]);

  return (
    <div className="space-y-6">
      <h2 className="text-2xl sm:text-3xl font-bold text-gray-800 dark:text-gray-100 text-center mb-6">
        Audio Transcriber
      </h2>
      <p className="text-gray-600 dark:text-gray-300 text-center">
        Upload an audio file and get a text transcription using Gemini.
      </p>

      <form onSubmit={handleSubmit} className="space-y-4 p-4 border border-gray-200 dark:border-gray-700 rounded-lg shadow-sm">
        <FileUpload
          id="upload-audio"
          label="Upload Audio File"
          accept="audio/*"
          onFileChange={handleFileChange}
          isLoading={isLoading}
          currentFile={audioFile}
        />

        {error && (
          <div className="bg-red-100 dark:bg-red-900 border border-red-400 text-red-700 dark:text-red-300 px-4 py-3 rounded relative" role="alert">
            <strong className="font-bold">Error: </strong>
            <span className="block sm:inline">{error}</span>
          </div>
        )}

        <div className="flex flex-col sm:flex-row justify-end space-y-3 sm:space-y-0 sm:space-x-3 mt-8">
          <Button
            type="button"
            onClick={onBack}
            variant="secondary"
            disabled={isLoading}
            className="w-full sm:w-auto"
          >
            Back to Tools
          </Button>
          <Button
            type="submit"
            isLoading={isLoading}
            disabled={isLoading}
            className="w-full sm:w-auto"
          >
            Transcribe Audio
          </Button>
        </div>
      </form>

      {transcription && (
        <div className="mt-8 p-4 border border-gray-200 dark:border-gray-700 rounded-lg shadow-md">
          <h3 className="text-xl font-bold text-gray-800 dark:text-gray-100 mb-4 text-center">Transcription:</h3>
          <TextArea
            id="transcription-output"
            label="Transcribed Text"
            value={transcription}
            readOnly
            rows={8}
            className="bg-gray-100 dark:bg-gray-800 cursor-default"
          />
        </div>
      )}
    </div>
  );
};
