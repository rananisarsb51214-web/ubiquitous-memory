import React, { useState, useCallback, useRef, useEffect } from 'react';
import { Button } from './Button';
import { LoadingSpinner } from './LoadingSpinner';
import { connectLiveAudioChat, sendLiveAudioInput, closeLiveAudioChat } from '../services/geminiService';
import { createBlob, decode, decodeAudioData } from '../utils/audioUtils';

interface VoiceChatProps {
  onBack: () => void;
}

const INPUT_SAMPLE_RATE = 16000;
const OUTPUT_SAMPLE_RATE = 24000;

export const VoiceChat: React.FC<VoiceChatProps> = ({ onBack }) => {
  const [isRecording, setIsRecording] = useState<boolean>(false);
  const [isLoading, setIsLoading] = useState<boolean>(false);
  const [error, setError] = useState<string | null>(null);
  const [userTranscription, setUserTranscription] = useState<string>('');
  const [modelTranscription, setModelTranscription] = useState<string>('');
  const [fullConversation, setFullConversation] = useState<string[]>([]);

  const mediaRecorderRef = useRef<MediaRecorder | null>(null);
  const audioContextRef = useRef<AudioContext | null>(null);
  const scriptProcessorRef = useRef<ScriptProcessorNode | null>(null);
  const outputAudioContextRef = useRef<AudioContext | null>(null);
  const nextStartTimeRef = useRef<number>(0);
  const audioSourcesRef = useRef<Set<AudioBufferSourceNode>>(new Set());

  // Function to clean up audio resources
  const cleanupAudio = useCallback(() => {
    if (scriptProcessorRef.current) {
      scriptProcessorRef.current.disconnect();
      scriptProcessorRef.current = null;
    }
    if (audioContextRef.current) {
      audioContextRef.current.close();
      audioContextRef.current = null;
    }
    if (outputAudioContextRef.current) {
      for (const source of audioSourcesRef.current.values()) {
        source.stop();
        source.disconnect();
      }
      audioSourcesRef.current.clear();
      outputAudioContextRef.current.close();
      outputAudioContextRef.current = null;
    }
    nextStartTimeRef.current = 0;
  }, []);

  const startRecording = useCallback(async () => {
    setIsLoading(true);
    setError(null);
    setUserTranscription('');
    setModelTranscription('');
    setFullConversation([]);
    cleanupAudio(); // Ensure previous audio resources are cleaned up

    try {
      // Request microphone access
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });

      // Setup input audio processing
      // Fix: Use type assertion for window.webkitAudioContext to resolve TypeScript error while adhering to guideline pattern.
      audioContextRef.current = new (window.AudioContext || (window as any).webkitAudioContext)({ sampleRate: INPUT_SAMPLE_RATE });
      const source = audioContextRef.current.createMediaStreamSource(stream);
      scriptProcessorRef.current = audioContextRef.current.createScriptProcessor(4096, 1, 1);

      scriptProcessorRef.current.onaudioprocess = (audioProcessingEvent) => {
        const inputData = audioProcessingEvent.inputBuffer.getChannelData(0);
        const pcmBlob = createBlob(inputData, INPUT_SAMPLE_RATE);
        sendLiveAudioInput(pcmBlob); // Send to Gemini Live API
      };

      source.connect(scriptProcessorRef.current);
      scriptProcessorRef.current.connect(audioContextRef.current.destination);

      // Setup output audio context
      // Fix: Use type assertion for window.webkitAudioContext to resolve TypeScript error while adhering to guideline pattern.
      outputAudioContextRef.current = new (window.AudioContext || (window as any).webkitAudioContext)({ sampleRate: OUTPUT_SAMPLE_RATE });

      // Connect to Gemini Live API
      await connectLiveAudioChat({
        onopen: () => {
          console.debug('Live session opened.');
          setIsRecording(true);
          setIsLoading(false);
        },
        onmessage: async (message) => {
          console.debug('Live message:', message);
          // Handle model's audio output
          const base64EncodedAudioString = message.serverContent?.modelTurn?.parts[0]?.inlineData?.data;
          if (base64EncodedAudioString && outputAudioContextRef.current) {
            nextStartTimeRef.current = Math.max(
              nextStartTimeRef.current,
              outputAudioContextRef.current.currentTime,
            );
            const audioBuffer = await decodeAudioData(
              decode(base64EncodedAudioString),
              outputAudioContextRef.current,
              OUTPUT_SAMPLE_RATE,
              1,
            );
            const sourceNode = outputAudioContextRef.current.createBufferSource();
            sourceNode.buffer = audioBuffer;
            sourceNode.connect(outputAudioContextRef.current.destination);
            sourceNode.addEventListener('ended', () => {
              audioSourcesRef.current.delete(sourceNode);
            });

            sourceNode.start(nextStartTimeRef.current);
            nextStartTimeRef.current = nextStartTimeRef.current + audioBuffer.duration;
            audioSourcesRef.current.add(sourceNode);
          }

          // Handle interruptions
          if (message.serverContent?.interrupted && outputAudioContextRef.current) {
            for (const sourceNode of audioSourcesRef.current.values()) {
              sourceNode.stop();
              audioSourcesRef.current.delete(sourceNode);
            }
            nextStartTimeRef.current = 0;
          }

          // Handle transcriptions
          if (message.serverContent?.outputTranscription) {
            setModelTranscription((prev) => prev + message.serverContent.outputTranscription.text);
          }
          if (message.serverContent?.inputTranscription) {
            setUserTranscription((prev) => prev + message.serverContent.inputTranscription.text);
          }
          if (message.serverContent?.turnComplete) {
            setFullConversation((prev) => [
              ...prev,
              `User: ${userTranscription + message.serverContent.inputTranscription.text}`,
              `AI: ${modelTranscription + message.serverContent.outputTranscription.text}`
            ]);
            setUserTranscription('');
            setModelTranscription('');
          }
        },
        onerror: (e) => {
          console.error('Live session error:', e);
          setError('Live audio chat error: ' + e.message);
          stopRecording(); // Stop on error
        },
        onclose: (e) => {
          console.debug('Live session closed:', e);
          setIsRecording(false);
          cleanupAudio();
          if (!e.wasClean) {
            setError('Live audio chat disconnected unexpectedly.');
          }
        },
      });

    } catch (err: any) {
      console.error("Error starting voice chat:", err);
      setError(err.message || "Failed to start voice chat. Please ensure microphone access.");
      setIsLoading(false);
      cleanupAudio();
    }
  }, [cleanupAudio, userTranscription, modelTranscription]);

  const stopRecording = useCallback(() => {
    setIsRecording(false);
    setIsLoading(false);
    if (mediaRecorderRef.current && mediaRecorderRef.current.state === 'recording') {
      mediaRecorderRef.current.stop();
    }
    closeLiveAudioChat();
    cleanupAudio();
  }, [cleanupAudio]);

  // Clean up on component unmount
  useEffect(() => {
    return () => {
      stopRecording();
    };
  }, [stopRecording]);

  return (
    <div className="space-y-6 flex flex-col h-[80vh]">
      <h2 className="text-2xl sm:text-3xl font-bold text-gray-800 dark:text-gray-100 text-center mb-4">
        Real-time Voice Chat
      </h2>
      <p className="text-gray-600 dark:text-gray-300 text-center mb-6">
        Engage in real-time, low-latency conversations with Gemini using your microphone.
        Requires a selected API key for billing and microphone access.
      </p>

      {error && (
        <div className="bg-red-100 dark:bg-red-900 border border-red-400 text-red-700 dark:text-red-300 px-4 py-3 rounded relative" role="alert">
          <strong className="font-bold">Error: </strong>
          <span className="block sm:inline">{error}</span>
        </div>
      )}

      <div className="flex-grow overflow-y-auto p-4 border border-gray-200 dark:border-gray-700 rounded-lg shadow-inner bg-gray-50 dark:bg-gray-900">
        {fullConversation.length === 0 && !isRecording && !isLoading ? (
          <p className="text-center text-gray-500 dark:text-gray-400">Press 'Start Voice Chat' to begin.</p>
        ) : (
          fullConversation.map((line, index) => (
            <div key={index} className={`mb-2 ${line.startsWith('User:') ? 'text-right' : 'text-left'}`}>
              <span className={`inline-block p-2 rounded-lg max-w-[80%] text-sm ${
                line.startsWith('User:')
                  ? 'bg-purple-100 text-purple-800 dark:bg-purple-900 dark:text-purple-200'
                  : 'bg-gray-100 text-gray-700 dark:bg-gray-800 dark:text-gray-100'
              }`}>
                {line}
              </span>
            </div>
          ))
        )}
        {isRecording && (
          <>
            {userTranscription && (
              <div className="text-right mb-2">
                <span className="inline-block p-2 rounded-lg max-w-[80%] text-sm bg-purple-100 text-purple-800 dark:bg-purple-900 dark:text-purple-200">
                  User: {userTranscription}
                </span>
              </div>
            )}
            {modelTranscription && (
              <div className="text-left mb-2">
                <span className="inline-block p-2 rounded-lg max-w-[80%] text-sm bg-gray-100 text-gray-700 dark:bg-gray-800 dark:text-gray-100">
                  AI: {modelTranscription}
                </span>
              </div>
            )}
            <div className="text-center">
              <LoadingSpinner size="sm" className="inline-block" />
              <span className="ml-2 text-gray-600 dark:text-gray-300 text-sm">Listening...</span>
            </div>
          </>
        )}
      </div>

      <div className="flex flex-col sm:flex-row justify-center space-y-3 sm:space-y-0 sm:space-x-3 mt-4">
        {isRecording ? (
          <Button
            onClick={stopRecording}
            variant="secondary"
            className="bg-red-600 hover:bg-red-700 text-white w-full sm:w-auto"
            disabled={isLoading}
          >
            Stop Voice Chat
          </Button>
        ) : (
          <Button
            onClick={startRecording}
            variant="primary"
            className="bg-green-600 hover:bg-green-700 text-white w-full sm:w-auto"
            isLoading={isLoading}
            disabled={isLoading}
          >
            {isLoading ? 'Connecting...' : 'Start Voice Chat'}
          </Button>
        )}
        <Button
          type="button"
          onClick={onBack}
          variant="outline"
          disabled={isLoading || isRecording}
          className="w-full sm:w-auto"
        >
          Back to Tools
        </Button>
      </div>
    </div>
  );
};