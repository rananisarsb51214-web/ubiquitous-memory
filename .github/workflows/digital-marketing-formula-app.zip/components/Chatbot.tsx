import React, { useState, useCallback, useRef, useEffect } from 'react';
import { TextArea } from './TextArea';
import { Button } from './Button';
import { sendChatMessage, resetChatbotSession } from '../services/geminiService';
import { LoadingSpinner } from './LoadingSpinner';
import { ChatbotResponseSchema } from '../types';

interface ChatbotProps {
  onBack: () => void;
}

interface ChatMessage {
  role: 'user' | 'model';
  text?: string; // Original text for fallback/display
  jsonResponse?: ChatbotResponseSchema; // Structured JSON response
}

export const Chatbot: React.FC<ChatbotProps> = ({ onBack }) => {
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [currentInput, setCurrentInput] = useState<string>('');
  const [isLoading, setIsLoading] = useState<boolean>(false);
  const [error, setError] = useState<string | null>(null);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  };

  useEffect(scrollToBottom, [messages]);

  useEffect(() => {
    // Reset chat session when component mounts/unmounts
    resetChatbotSession();
    setMessages([]);
    setCurrentInput('');
    setError(null);
  }, []);

  const handleSubmit = useCallback(async (e: React.FormEvent) => {
    e.preventDefault();
    const userMessage = currentInput.trim();
    if (!userMessage) return;

    setMessages((prev) => [...prev, { role: 'user', text: userMessage }]);
    setCurrentInput('');
    setIsLoading(true);
    setError(null);

    try {
      const modelResponse = await sendChatMessage(userMessage);

      if (typeof modelResponse === 'string') {
        // It's raw text
        setMessages((prev) => [...prev, { role: 'model', text: modelResponse }]);
      } else {
        // It's a structured JSON response
        setMessages((prev) => [...prev, { role: 'model', jsonResponse: modelResponse, text: modelResponse.response }]);
      }
    } catch (err: any) {
      console.error("Error sending chat message:", err);
      setError(err.message || "Failed to get response. Please try again.");
    } finally {
      setIsLoading(false);
    }
  }, [currentInput]);

  return (
    <div className="space-y-6 flex flex-col h-[70vh]">
      <h2 className="text-2xl sm:text-3xl font-bold text-gray-800 dark:text-gray-100 text-center mb-4">
        AI Chatbot
      </h2>
      <p className="text-gray-600 dark:text-gray-300 text-center mb-6">
        Chat with Gemini! Responses are provided in a structured JSON format.
        Uses `gemini-3-pro-preview` for complex reasoning.
      </p>

      <div className="flex-grow overflow-y-auto p-4 border border-gray-200 dark:border-gray-700 rounded-lg shadow-inner bg-gray-50 dark:bg-gray-900">
        {messages.length === 0 && !isLoading ? (
          <p className="text-center text-gray-500 dark:text-gray-400">Start a conversation...</p>
        ) : (
          messages.map((msg, index) => (
            <div key={index} className={`mb-4 ${msg.role === 'user' ? 'text-right' : 'text-left'}`}>
              <div className={`inline-block p-3 rounded-lg max-w-[80%] ${
                msg.role === 'user'
                  ? 'bg-purple-600 text-white dark:bg-purple-500'
                  : 'bg-gray-200 text-gray-800 dark:bg-gray-700 dark:text-gray-100'
              }`}>
                {msg.jsonResponse ? (
                  <pre className="whitespace-pre-wrap font-mono text-sm bg-gray-100 dark:bg-gray-800 p-2 rounded-md text-gray-800 dark:text-gray-100">
                    {JSON.stringify(msg.jsonResponse, null, 2)}
                  </pre>
                ) : (
                  msg.text
                )}
              </div>
            </div>
          ))
        )}
        {isLoading && (
          <div className="text-center">
            <LoadingSpinner size="sm" className="inline-block" />
          </div>
        )}
        <div ref={messagesEndRef} />
      </div>

      <form onSubmit={handleSubmit} className="flex gap-3 mt-4">
        <TextArea
          id="chat-input"
          placeholder="Type your message here..."
          value={currentInput}
          onChange={(e) => setCurrentInput(e.target.value)}
          rows={1}
          disabled={isLoading}
          className="flex-grow resize-none"
        />
        <Button type="submit" isLoading={isLoading} disabled={isLoading} className="px-6 py-2">
          Send
        </Button>
      </form>

      {error && (
        <div className="bg-red-100 dark:bg-red-900 border border-red-400 text-red-700 dark:text-red-300 px-4 py-3 rounded relative mt-4" role="alert">
          <strong className="font-bold">Error: </strong>
          <span className="block sm:inline">{error}</span>
        </div>
      )}

      <div className="text-right mt-4">
        <Button
          type="button"
          onClick={onBack}
          variant="secondary"
          disabled={isLoading}
          className="w-full sm:w-auto"
        >
          Back to Tools
        </Button>
      </div>
    </div>
  );
};