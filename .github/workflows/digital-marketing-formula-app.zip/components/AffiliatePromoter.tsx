import React, { useState, useCallback, useEffect } from 'react';
import { FeatureCardProps, FormField, FieldType, FormValues } from '../types';
import { Input } from './Input';
import { TextArea } from './TextArea';
import { Button } from './Button';
import { Select } from './Select';
import { ContentDisplay } from './ContentDisplay';
import { generateMarketingContent } from '../services/geminiService';

interface AffiliatePromoterProps {
  feature: FeatureCardProps;
  onBack: () => void;
}

export const AffiliatePromoter: React.FC<AffiliatePromoterProps> = ({ feature, onBack }) => {
  const [formValues, setFormValues] = useState<FormValues>(() => {
    const initialValues: FormValues = {};
    feature.fields?.forEach((field) => {
      initialValues[field.id] = '';
    });
    return initialValues;
  });
  const [generatedContent, setGeneratedContent] = useState<string | null>(null);
  const [isLoading, setIsLoading] = useState<boolean>(false);
  const [error, setError] = useState<string | null>(null);
  const [fieldErrors, setFieldErrors] = useState<{ [key: string]: string }>({});

  useEffect(() => {
    // Reset form values when feature changes
    const initialValues: FormValues = {};
    feature.fields?.forEach((field) => {
      initialValues[field.id] = '';
    });
    setFormValues(initialValues);
    setGeneratedContent(null);
    setError(null);
    setFieldErrors({});
  }, [feature]);

  const handleChange = useCallback((
    e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>
  ) => {
    const { id, value } = e.target;
    setFormValues((prev) => ({ ...prev, [id]: value }));
    if (fieldErrors[id]) {
      setFieldErrors((prev) => {
        const newErrors = { ...prev };
        delete newErrors[id];
        return newErrors;
      });
    }
  }, [fieldErrors]);

  const validateForm = useCallback(() => {
    const errors: { [key: string]: string } = {};
    feature.fields?.forEach((field) => {
      if (field.required && !formValues[field.id]) {
        errors[field.id] = `${field.label} is required.`;
      }
    });
    setFieldErrors(errors);
    return Object.keys(errors).length === 0;
  }, [formValues, feature.fields]);

  const handleSubmit = useCallback(async (e: React.FormEvent) => {
    e.preventDefault();
    if (!validateForm()) {
      return;
    }

    setIsLoading(true);
    setError(null);
    setGeneratedContent(null);

    try {
      const content = await generateMarketingContent(feature, formValues);
      setGeneratedContent(content);
    } catch (err: any) {
      console.error("Error generating affiliate content:", err);
      setError(err.message || "Failed to generate content. Please try again.");
    } finally {
      setIsLoading(false);
    }
  }, [feature, formValues, validateForm]);

  const renderField = useCallback((field: FormField) => {
    const commonProps = {
      id: field.id,
      label: field.label,
      placeholder: field.placeholder,
      value: formValues[field.id] as string || '',
      onChange: handleChange,
      required: field.required,
      error: fieldErrors[field.id],
      disabled: isLoading,
    };

    switch (field.type) {
      case FieldType.TEXT:
        return <Input key={field.id} type="text" {...commonProps} />;
      case FieldType.TEXTAREA:
        return <TextArea key={field.id} {...commonProps} />;
      case FieldType.SELECT:
        return (
          <Select
            key={field.id}
            options={field.options || []}
            {...commonProps}
          />
        );
      default:
        return null;
    }
  }, [formValues, handleChange, fieldErrors, isLoading]);

  return (
    <div className="space-y-6">
      <h2 className="text-2xl sm:text-3xl font-bold text-gray-800 dark:text-gray-100 text-center mb-6">
        {feature.name}
      </h2>
      <p className="text-gray-600 dark:text-gray-300 text-center">
        {feature.description}
      </p>

      {generatedContent ? (
        <ContentDisplay
          content={generatedContent}
          onBack={() => setGeneratedContent(null)} // Clear content to show form again
          onBackToMain={onBack} // Go back to main feature selection
        />
      ) : (
        <form onSubmit={handleSubmit} className="space-y-4 p-4 border border-gray-200 dark:border-gray-700 rounded-lg shadow-sm">
          {feature.fields?.map(renderField)}

          {error && (
            <div className="bg-red-100 dark:bg-red-900 border border-red-400 text-red-700 dark:text-red-300 px-4 py-3 rounded relative" role="alert">
              <strong className="font-bold">Error: </strong>
              <span className="block sm:inline">{error}</span>
            </div>
          )}

          <div className="flex flex-col sm:flex-row justify-end space-y-3 sm:space-y-0 sm:space-x-3 mt-8">
            <Button
              type="button"
              onClick={onBack}
              variant="secondary"
              disabled={isLoading}
              className="w-full sm:w-auto"
            >
              Back to Tools
            </Button>
            <Button
              type="submit"
              isLoading={isLoading}
              disabled={isLoading}
              className="w-full sm:w-auto"
            >
              Generate Content
            </Button>
          </div>
        </form>
      )}
    </div>
  );
};