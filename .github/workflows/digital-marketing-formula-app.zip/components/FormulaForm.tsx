import React, { useState, useEffect, useCallback } from 'react';
import { FeatureCardProps, FormField, FieldType, FormValues } from '../types';
import { Input } from './Input';
import { TextArea } from './TextArea';
import { Button } from './Button';
import { Select } from './Select';

interface FormulaFormProps {
  formula: FeatureCardProps; // Changed from MarketingFormula to FeatureCardProps
  onSubmit: (values: FormValues) => void;
  onBack: () => void; // This now means 'back to main feature selection'
  isLoading: boolean;
  error: string | null;
}

export const FormulaForm: React.FC<FormulaFormProps> = ({
  formula,
  onSubmit,
  onBack,
  isLoading,
  error,
}) => {
  const [formValues, setFormValues] = useState<FormValues>(() => {
    // Initialize form values from formula fields
    const initialValues: FormValues = {};
    formula.fields?.forEach((field) => { // Use optional chaining as fields might be undefined for other feature types
      initialValues[field.id] = '';
    });
    return initialValues;
  });
  const [fieldErrors, setFieldErrors] = useState<{ [key: string]: string }>({});

  useEffect(() => {
    // Reset form values when formula changes
    const initialValues: FormValues = {};
    formula.fields?.forEach((field) => {
      initialValues[field.id] = '';
    });
    setFormValues(initialValues);
    setFieldErrors({}); // Clear field errors
  }, [formula]);

  const handleChange = useCallback((
    e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>
  ) => {
    const { id, value } = e.target;
    setFormValues((prev) => ({ ...prev, [id]: value }));
    if (fieldErrors[id]) {
      setFieldErrors((prev) => {
        const newErrors = { ...prev };
        delete newErrors[id];
        return newErrors;
      });
    }
  }, [fieldErrors]);

  const validateForm = useCallback(() => {
    const errors: { [key: string]: string } = {};
    formula.fields?.forEach((field) => {
      if (field.required && !formValues[field.id]) {
        errors[field.id] = `${field.label} is required.`;
      }
    });
    setFieldErrors(errors);
    return Object.keys(errors).length === 0;
  }, [formValues, formula.fields]);

  const handleSubmit = useCallback((e: React.FormEvent) => {
    e.preventDefault();
    if (validateForm()) {
      onSubmit(formValues);
    }
  }, [formValues, onSubmit, validateForm]);

  const renderField = useCallback((field: FormField) => {
    const commonProps = {
      id: field.id,
      label: field.label,
      placeholder: field.placeholder,
      value: formValues[field.id] as string || '', // Assume string for text/textarea/select
      onChange: handleChange,
      required: field.required,
      error: fieldErrors[field.id],
      disabled: isLoading,
    };

    switch (field.type) {
      case FieldType.TEXT:
        return <Input key={field.id} type="text" {...commonProps} />;
      case FieldType.TEXTAREA:
        return <TextArea key={field.id} {...commonProps} />;
      case FieldType.NUMBER:
        return <Input key={field.id} type="number" {...commonProps} />;
      case FieldType.SELECT:
        return (
          <Select
            key={field.id}
            options={field.options || []}
            {...commonProps}
          />
        );
      default:
        return null;
    }
  }, [formValues, handleChange, fieldErrors, isLoading]);


  return (
    <form onSubmit={handleSubmit} className="space-y-6">
      {formula.fields?.map(renderField)}

      {error && (
        <div className="bg-red-100 dark:bg-red-900 border border-red-400 text-red-700 dark:text-red-300 px-4 py-3 rounded relative" role="alert">
          <strong className="font-bold">Error: </strong>
          <span className="block sm:inline">{error}</span>
        </div>
      )}

      <div className="flex flex-col sm:flex-row justify-end space-y-3 sm:space-y-0 sm:space-x-3 mt-8">
        <Button
          type="button"
          onClick={onBack}
          variant="secondary"
          disabled={isLoading}
          className="w-full sm:w-auto"
        >
          Back to Tools
        </Button>
        <Button
          type="submit"
          isLoading={isLoading}
          disabled={isLoading}
          className="w-full sm:w-auto"
        >
          Generate Content
        </Button>
      </div>
    </form>
  );
};
