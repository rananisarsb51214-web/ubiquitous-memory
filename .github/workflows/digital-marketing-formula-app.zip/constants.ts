import { FeatureCardProps, FieldType, FeatureType, ImageAspectRatio } from './types';

export const FEATURE_CARDS: FeatureCardProps[] = [
  // Existing Marketing Formulas
  {
    id: 'social-post',
    name: 'Social Media Post',
    description: 'Generate a catchy social media post for your product or service.',
    icon: '🚀',
    featureType: FeatureType.FORMULA,
    fields: [
      { id: 'productName', label: 'Product/Service Name', type: FieldType.TEXT, placeholder: 'e.g., AI Marketing Assistant', required: true },
      { id: 'keyFeature', label: 'Key Feature/Benefit', type: FieldType.TEXT, placeholder: 'e.g., Automates content creation', required: true },
      { id: 'targetAudience', label: 'Target Audience', type: FieldType.TEXT, placeholder: 'e.g., Small business owners', required: false },
      { id: 'callToAction', label: 'Call to Action', type: FieldType.TEXT, placeholder: 'e.g., Learn more', required: true },
      { id: 'tone', label: 'Tone of Voice', type: FieldType.SELECT, options: ['Professional', 'Friendly', 'Exciting', 'Humorous'], required: false },
    ],
    promptTemplate: (values) => `
      Generate a compelling social media post for ${values.productName}.
      Highlight the key feature/benefit: "${values.keyFeature}".
      ${values.targetAudience ? `Tailored for: ${values.targetAudience}.` : ''}
      Include a clear call to action: "${values.callToAction}".
      ${values.tone ? `The tone should be: "${values.tone}".` : ''}
      Make it engaging and concise, suitable for platforms like Instagram or LinkedIn.
    `,
  },
  {
    id: 'email-subject',
    name: 'Email Subject Line',
    description: 'Craft an attention-grabbing email subject line.',
    icon: '📧',
    featureType: FeatureType.FORMULA,
    fields: [
      { id: 'emailTopic', label: 'Email Topic/Goal', type: FieldType.TEXT, placeholder: 'e.g., New product launch, Event invitation', required: true },
      { id: 'keyBenefit', label: 'Key Benefit/Offer', type: FieldType.TEXT, placeholder: 'e.g., 20% off, Free trial', required: false },
      { id: 'urgency', label: 'Urgency/Scarcity', type: FieldType.TEXT, placeholder: 'e.g., Limited time, Don\'t miss out', required: false },
    ],
    promptTemplate: (values) => `
      Generate 5 creative and engaging email subject lines for an email about: "${values.emailTopic}".
      ${values.keyBenefit ? `Highlighting the benefit/offer: "${values.keyBenefit}".` : ''}
      ${values.urgency ? `Add a sense of urgency: "${values.urgency}".` : ''}
      Make them concise and designed to maximize open rates.
    `,
  },
  {
    id: 'ad-copy',
    name: 'Short Ad Copy',
    description: 'Write concise and effective ad copy for digital platforms.',
    icon: '💡',
    featureType: FeatureType.FORMULA,
    fields: [
      { id: 'productName', label: 'Product/Service Name', type: FieldType.TEXT, placeholder: 'e.g., Cloud Storage Solution', required: true },
      { id: 'uniqueSellingPoint', label: 'Unique Selling Point', type: FieldType.TEXT, placeholder: 'e.g., Unlimited space, Military-grade encryption', required: true },
      { id: 'targetKeyword', label: 'Target Keyword (optional)', type: FieldType.TEXT, placeholder: 'e.g., secure cloud storage', required: false },
      { id: 'callToAction', label: 'Call to Action', type: FieldType.TEXT, placeholder: 'e.g., Get Started Free', required: true },
    ],
    promptTemplate: (values) => `
      Generate 3 short, compelling ad copies for "${values.productName}".
      The unique selling point is: "${values.uniqueSellingPoint}".
      ${values.targetKeyword ? `Optimize for the keyword: "${values.targetKeyword}".` : ''}
      Include a strong call to action: "${values.callToAction}".
      Each ad copy should be no more than 90 characters.
    `,
  },
  {
    id: 'blog-outline',
    name: 'Blog Post Outline',
    description: 'Create a structured outline for a blog post on a given topic.',
    icon: '✍️',
    featureType: FeatureType.FORMULA,
    fields: [
      { id: 'blogTopic', label: 'Blog Post Topic', type: FieldType.TEXTAREA, placeholder: 'e.g., The Future of AI in Content Marketing', required: true },
      { id: 'targetAudience', label: 'Target Audience', type: FieldType.TEXT, placeholder: 'e.g., Marketing professionals', required: false },
      { id: 'mainPoints', label: 'Key points to cover (optional)', type: FieldType.TEXTAREA, placeholder: 'e.g., Automation benefits, ethical considerations', required: false },
    ],
    promptTemplate: (values) => `
      Generate a detailed blog post outline for the topic: "${values.blogTopic}".
      ${values.targetAudience ? `The target audience is: ${values.targetAudience}.` : ''}
      ${values.mainPoints ? `Include these key points: ${values.mainPoints}.` : ''}
      The outline should include an introduction, 3-5 main sections with sub-points, and a conclusion.
    `,
  },

  // New AI Features
  {
    id: 'image-generator',
    name: 'AI Image Generator',
    description: 'Create unique images from text prompts with aspect ratio control.',
    icon: '🖼️',
    featureType: FeatureType.IMAGE_GEN,
  },
  {
    id: 'image-editor',
    name: 'AI Image Editor',
    description: 'Edit existing images using natural language instructions.',
    icon: '🖌️',
    featureType: FeatureType.IMAGE_EDIT,
  },
  {
    id: 'text-to-speech',
    name: 'Text-to-Speech',
    description: 'Convert text into natural-sounding speech.',
    icon: '🔊',
    featureType: FeatureType.TEXT_TO_SPEECH,
  },
  {
    id: 'audio-transcriber',
    name: 'Audio Transcriber',
    description: 'Transcribe audio files into text.',
    icon: '🎤',
    featureType: FeatureType.AUDIO_TRANSCRIPT,
  },
  {
    id: 'video-analyzer',
    name: 'Video Analyzer',
    description: 'Analyze videos to extract key information using AI.',
    icon: '📹',
    featureType: FeatureType.VIDEO_ANALYSIS,
  },
  {
    id: 'ai-chatbot',
    name: 'AI Chatbot',
    description: 'Have a conversation with Gemini for various inquiries.',
    icon: '🤖',
    featureType: FeatureType.CHATBOT,
  },
  {
    id: 'voice-chat',
    name: 'Voice Chat',
    description: 'Engage in real-time voice conversations with AI.',
    icon: '🗣️',
    featureType: FeatureType.VOICE_CHAT,
  },
  {
    id: 'affiliate-promoter',
    name: 'Affiliate Product Promoter',
    description: 'Generate engaging promotional content for your affiliate products.',
    icon: '🔗',
    featureType: FeatureType.AFFILIATE_PROMOTION,
    fields: [
      { id: 'productName', label: 'Product Name', type: FieldType.TEXT, placeholder: 'e.g., "Smart Gadget Pro"', required: true },
      { id: 'productDescription', label: 'Short Product Description', type: FieldType.TEXTAREA, placeholder: 'e.g., "A revolutionary device that simplifies daily tasks."', required: true },
      { id: 'targetAudience', label: 'Target Audience', type: FieldType.TEXT, placeholder: 'e.g., "Tech enthusiasts, Busy professionals"', required: false },
      { id: 'keySellingPoints', label: 'Key Selling Points/Benefits', type: FieldType.TEXTAREA, placeholder: 'e.g., "Time-saving, user-friendly, durable design"', required: true },
      { id: 'affiliateLink', label: 'Affiliate Link', type: FieldType.TEXT, placeholder: 'e.g., "https://youraffiliatelink.com/product"', required: true },
      { id: 'contentType', label: 'Desired Content Type', type: FieldType.SELECT, options: ['Social Media Post', 'Email Introduction', 'Short Blog Snippet', 'Video Hook Idea'], required: true },
      { id: 'tone', label: 'Tone of Voice', type: FieldType.SELECT, options: ['Professional', 'Friendly', 'Exciting', 'Humorous', 'Informative'], required: false },
    ],
    promptTemplate: (values) => `
      Generate a ${values.contentType} to promote the affiliate product "${values.productName}".
      Product Description: "${values.productDescription}".
      Key Selling Points: "${values.keySellingPoints}".
      ${values.targetAudience ? `Target Audience: "${values.targetAudience}".` : ''}
      Include a strong call to action to click the affiliate link: "${values.affiliateLink}".
      The content should be engaging and persuasive.
      ${values.tone ? `The tone should be: "${values.tone}".` : ''}
    `,
  },
  {
    id: 'cartoon-restyle',
    name: 'Cartoon Style Restyler',
    description: 'Transform your photos into a fun cartoon art style.',
    icon: '🎨',
    featureType: FeatureType.CARTOON_RESTYLE,
  },
  {
    id: 'youtube-thumbnail-generator',
    name: 'YouTube Thumbnail Idea Generator',
    description: 'Generate creative and clickable YouTube thumbnail concepts.',
    icon: '📸',
    featureType: FeatureType.FORMULA,
    fields: [
      { id: 'videoTopic', label: 'Video Topic', type: FieldType.TEXTAREA, placeholder: 'e.g., "Top 5 Productivity Hacks for Remote Workers"', required: true },
      { id: 'targetAudience', label: 'Target Audience (optional)', type: FieldType.TEXT, placeholder: 'e.g., "Students, Freelancers, Entrepreneurs"', required: false },
      { id: 'thumbnailStyle', label: 'Desired Thumbnail Style', type: FieldType.SELECT, options: ['Minimalist', 'Vibrant', 'Professional', 'Humorous', 'Clickbait', 'Informative', 'Action-oriented'], required: true },
    ],
    promptTemplate: (values) => `
      Generate 3-5 distinct YouTube thumbnail concepts for a video titled or about: "${values.videoTopic}".
      ${values.targetAudience ? `The target audience is: "${values.targetAudience}".` : ''}
      The desired thumbnail style is: "${values.thumbnailStyle}".
      For each concept, provide a brief description focusing on visual elements and text overlays.
      Ensure the concepts are creative, attention-grabbing, and highly clickable.
    `,
  },
];