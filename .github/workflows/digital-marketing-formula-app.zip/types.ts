// types.ts
import { Type } from '@google/genai'; // Import Type enum

/**
 * Defines the type of input field.
 */
export enum FieldType {
  TEXT = 'text',
  TEXTAREA = 'textarea',
  NUMBER = 'number',
  SELECT = 'select',
  FILE_IMAGE = 'file_image',
  FILE_AUDIO = 'file_audio',
  FILE_VIDEO = 'file_video',
}

/**
 * Defines the type of AI feature.
 */
export enum FeatureType {
  FORMULA = 'formula',
  IMAGE_GEN = 'image_gen',
  IMAGE_EDIT = 'image_edit',
  TEXT_TO_SPEECH = 'text_to_speech',
  AUDIO_TRANSCRIPT = 'audio_transcript',
  VIDEO_ANALYSIS = 'video_analysis',
  CHATBOT = 'chatbot',
  VOICE_CHAT = 'voice_chat',
  AFFILIATE_PROMOTION = 'affiliate_promotion',
  CARTOON_RESTYLE = 'cartoon_restyle', // Added new feature type
}

/**
 * Defines available image aspect ratios.
 */
export enum ImageAspectRatio {
  _1_1 = '1:1',
  _2_3 = '2:3',
  _3_2 = '3:2',
  _3_4 = '3:4',
  _4_3 = '4:3',
  _9_16 = '9:16',
  _16_9 = '16:9',
  _21_9 = '21:9',
}

/**
 * Represents a single field in a marketing formula's input form.
 */
export interface FormField {
  id: string;
  label: string;
  type: FieldType;
  placeholder?: string;
  required?: boolean;
  options?: string[]; // For FieldType.SELECT
  accept?: string; // For File inputs (e.g., "image/*", "audio/*")
}

/**
 * Represents a generic feature card that can be selected in the app.
 */
export interface FeatureCardProps {
  id: string;
  name: string;
  description: string;
  icon: string; // Emoji or icon component identifier
  featureType: FeatureType;
  fields?: FormField[]; // Optional, for FORMULA type features
  promptTemplate?: (values: FormValues) => string; // Optional, for FORMULA type features
}

/**
 * Type for the values submitted from a dynamic form.
 * Keys are field IDs, values are the input strings/numbers.
 */
export interface FormValues {
  [key: string]: string | number | File | null;
}

/**
 * Expected JSON structure for the Chatbot's responses.
 */
export interface ChatbotResponseSchema {
  response: string;
  sentiment?: string;
  keywords?: string[];
}

// For Live Chat API
export interface LiveChatCallbacks {
  onopen: () => void;
  onmessage: (message: any) => void;
  onerror: (e: ErrorEvent) => void;
  onclose: (e: CloseEvent) => void;
}
