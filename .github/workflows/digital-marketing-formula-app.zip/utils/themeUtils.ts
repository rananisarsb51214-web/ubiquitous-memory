// utils/themeUtils.ts

type Theme = 'light' | 'dark';
type ThemePreference = Theme | 'system';

const THEME_KEY = 'theme-preference';

/**
 * Applies the given theme to the HTML element.
 * @param theme The theme to apply ('light' or 'dark').
 */
export function applyTheme(theme: Theme) {
  const html = document.documentElement;
  if (theme === 'dark') {
    html.classList.add('dark');
  } else {
    html.classList.remove('dark');
  }
}

/**
 * Gets the preferred theme from local storage or system preference.
 * @returns The resolved theme ('light' or 'dark').
 */
export function getInitialTheme(): Theme {
  const storedPreference = localStorage.getItem(THEME_KEY) as ThemePreference | null;

  if (storedPreference) {
    if (storedPreference === 'system') {
      return window.matchMedia('(prefers-color-scheme: dark)').matches ? 'dark' : 'light';
    }
    return storedPreference;
  }

  // Default to system preference if no stored preference
  return window.matchMedia('(prefers-color-scheme: dark)').matches ? 'dark' : 'light';
}

/**
 * Sets the theme preference in local storage.
 * @param preference The theme preference to store ('light', 'dark', or 'system').
 */
export function setThemePreference(preference: ThemePreference) {
  localStorage.setItem(THEME_KEY, preference);
}

/**
 * Listens for changes in the system's preferred color scheme.
 * @param callback A function to be called with the new theme ('light' or 'dark').
 * @returns A cleanup function to unsubscribe from the listener.
 */
export function listenForSystemThemeChanges(callback: (theme: Theme) => void): () => void {
  const mediaQuery = window.matchMedia('(prefers-color-scheme: dark)');
  const handler = (event: MediaQueryListEvent) => {
    const storedPreference = localStorage.getItem(THEME_KEY) as ThemePreference | null;
    // Only update if the user hasn't explicitly set a theme, or if their preference is 'system'
    if (!storedPreference || storedPreference === 'system') {
      callback(event.matches ? 'dark' : 'light');
    }
  };

  mediaQuery.addEventListener('change', handler);
  return () => mediaQuery.removeEventListener('change', handler);
}
