import { GoogleGenAI, GenerateContentResponse, Chat, Modality, Type } from "@google/genai";
import { FeatureCardProps, FormValues, ImageAspectRatio, LiveChatCallbacks, ChatbotResponseSchema } from '../types';
import { blobToBase64, decode, decodeAudioData, encode } from '../utils/audioUtils';

/**
 * Initializes the GoogleGenAI client.
 * Note: The API key is assumed to be provided via process.env.API_KEY.
 * The client is created inside the function to ensure the latest API_KEY is used,
 * especially after a potential `openSelectKey()` call.
 */
const getGeminiClient = () => {
  if (!process.env.API_KEY) {
    throw new Error("API_KEY is not set. Please ensure it is configured in your environment.");
  }
  return new GoogleGenAI({ apiKey: process.env.API_KEY });
};

/**
 * Handles API key selection for models that require a paid key.
 */
async function ensureApiKeySelected(): Promise<void> {
  if (window.aistudio && typeof window.aistudio.hasSelectedApiKey === 'function') {
    const hasKey = await window.aistudio.hasSelectedApiKey();
    if (!hasKey) {
      // If not selected, prompt the user. Assume success after opening the dialog.
      // As per guidelines, proceed immediately without waiting for actual selection confirmation.
      await window.aistudio.openSelectKey();
      console.log("User prompted to select API key. Proceeding with generation.");
    }
  }
}

async function handleApiError(error: any): Promise<never> {
  console.error("Gemini API call failed:", error);
  if (error.message && error.message.includes("Requested entity was not found.")) {
    console.warn("API key might be invalid or not selected. Prompting user to select a key.");
    if (window.aistudio && typeof window.aistudio.openSelectKey === 'function') {
      await window.aistudio.openSelectKey(); // Prompt user to re-select key
      throw new Error("Your API key may be invalid or billing is not enabled. Please select a valid key. See ai.google.dev/gemini-api/docs/billing");
    }
    throw new Error("API key error. Please check your setup or contact support.");
  }
  throw new Error(`Error generating content: ${error.message || 'Unknown error'}`);
}

// --- General Text Content Generation (from formulas) ---
export async function generateMarketingContent(
  formula: FeatureCardProps,
  formValues: FormValues
): Promise<string> {
  if (!formula.promptTemplate) {
    throw new Error("Prompt template is missing for this formula.");
  }
  const prompt = formula.promptTemplate(formValues);

  try {
    const ai = getGeminiClient(); // Create client here to get potentially updated API key
    const response = await ai.models.generateContent({
      model: 'gemini-3-flash-preview', // Using gemini-3-flash-preview for general text tasks
      contents: prompt,
      config: {
        temperature: 0.7,
        topK: 64,
        topP: 0.95,
        maxOutputTokens: 2048,
        thinkingConfig: { thinkingBudget: 512 }, // Balance between thinking and output
      },
    });

    const textOutput = response.text;
    if (!textOutput) {
      throw new Error("Gemini API returned an empty response.");
    }

    return textOutput;
  } catch (error: any) {
    return handleApiError(error);
  }
}

// --- Image Generation ---
export async function generateImage(prompt: string, aspectRatio: ImageAspectRatio): Promise<string> {
  try {
    await ensureApiKeySelected(); // Ensure API key is selected for paid models
    const ai = getGeminiClient();
    const response = await ai.models.generateContent({
      model: 'gemini-3-pro-image-preview', // High-quality image generation model
      contents: {
        parts: [
          { text: prompt },
        ],
      },
      config: {
        imageConfig: {
          aspectRatio: aspectRatio,
          imageSize: "1K" // Defaulting to 1K, user can request 2K/4K if needed.
        },
      },
    });

    for (const part of response.candidates[0].content.parts) {
      if (part.inlineData) {
        return `data:${part.inlineData.mimeType};base64,${part.inlineData.data}`;
      }
    }
    throw new Error("No image data found in the response.");
  } catch (error: any) {
    return handleApiError(error);
  }
}

// --- Image Editing ---
export async function editImage(base64ImageData: string, mimeType: string, prompt: string): Promise<string> {
  try {
    const ai = getGeminiClient();
    const response = await ai.models.generateContent({
      model: 'gemini-2.5-flash-image', // Image editing model
      contents: {
        parts: [
          {
            inlineData: {
              data: base64ImageData,
              mimeType: mimeType,
            },
          },
          {
            text: prompt,
          },
        ],
      },
    });

    for (const part of response.candidates[0].content.parts) {
      if (part.inlineData) {
        return `data:${part.inlineData.mimeType};base64,${part.inlineData.data}`;
      }
    }
    throw new Error("No image data found in the response.");
  } catch (error: any) {
    return handleApiError(error);
  }
}

// --- Text-to-Speech ---
export async function generateSpeech(text: string, voiceName: string = 'Zephyr'): Promise<AudioBuffer> {
  try {
    const ai = getGeminiClient();
    const response = await ai.models.generateContent({
      model: "gemini-2.5-flash-preview-tts",
      contents: [{ parts: [{ text: text }] }],
      config: {
        responseModalities: [Modality.AUDIO],
        speechConfig: {
          voiceConfig: {
            prebuiltVoiceConfig: { voiceName: voiceName },
          },
        },
      },
    });

    const base64Audio = response.candidates?.[0]?.content?.parts?.[0]?.inlineData?.data;
    if (!base64Audio) {
      throw new Error("No audio data received from TTS API.");
    }

    const outputAudioContext = new (window.AudioContext || (window as any).webkitAudioContext)({ sampleRate: 24000 });
    const audioBuffer = await decodeAudioData(
      decode(base64Audio),
      outputAudioContext,
      24000,
      1, // Assuming single channel as per example
    );
    return audioBuffer;
  } catch (error: any) {
    return handleApiError(error);
  }
}

// --- Audio Transcription ---
export async function transcribeAudio(file: File): Promise<string> {
  try {
    const base64AudioData = await blobToBase64(file);
    const ai = getGeminiClient();
    const response = await ai.models.generateContent({
      model: 'gemini-3-flash-preview', // Flash model for faster transcription
      contents: {
        parts: [
          {
            inlineData: {
              data: base64AudioData,
              mimeType: file.type,
            },
          },
          {
            text: 'Transcribe the audio provided.',
          }
        ],
      },
      config: {
        maxOutputTokens: 1024,
        thinkingConfig: { thinkingBudget: 256 },
      }
    });

    const textOutput = response.text;
    if (!textOutput) {
      throw new Error("Gemini API returned an empty transcription.");
    }
    return textOutput;
  } catch (error: any) {
    return handleApiError(error);
  }
}


// --- Video Analysis ---
export async function analyzeVideo(file: File, prompt: string): Promise<string> {
  try {
    await ensureApiKeySelected(); // Video analysis often requires Pro models
    const base64VideoData = await blobToBase64(file);
    const ai = getGeminiClient();
    const response = await ai.models.generateContent({
      model: 'gemini-3-pro-preview', // Gemini Pro for complex video understanding
      contents: {
        parts: [
          {
            inlineData: {
              data: base64VideoData,
              mimeType: file.type,
            },
          },
          {
            text: prompt,
          }
        ],
      },
      config: {
        thinkingConfig: { thinkingBudget: 32768 }, // Max thinking budget for Pro model
      },
    });

    const textOutput = response.text;
    if (!textOutput) {
      throw new Error("Gemini API returned an empty video analysis.");
    }
    return textOutput;
  } catch (error: any) {
    return handleApiError(error);
  }
}

// --- AI Chatbot (Text-based) ---
let chatInstance: Chat | null = null;
const CHATBOT_MODEL = 'gemini-3-pro-preview';

export async function sendChatMessage(message: string): Promise<ChatbotResponseSchema | string> {
  try {
    const ai = getGeminiClient();
    if (!chatInstance) {
      chatInstance = ai.chats.create({
        model: CHATBOT_MODEL,
        config: {
          thinkingConfig: { thinkingBudget: 32768 }, // Max thinking budget for Pro model
          temperature: 0.8,
          topP: 0.9,
          responseMimeType: "application/json", // Request JSON output
          responseSchema: { // Define expected JSON schema
            type: Type.OBJECT,
            properties: {
              response: {
                type: Type.STRING,
                description: "The main response to the user's query."
              },
              sentiment: {
                type: Type.STRING,
                description: "The overall sentiment of the response (e.g., positive, neutral, negative)."
              },
              keywords: {
                type: Type.ARRAY,
                items: { type: Type.STRING },
                description: "Key terms from the response."
              }
            },
            required: ["response"],
          },
        },
      });
    }

    const streamResponse = await chatInstance.sendMessageStream({ message: message });
    let fullResponse = '';
    for await (const chunk of streamResponse) {
      const c = chunk as GenerateContentResponse;
      if (c.text) {
        fullResponse += c.text;
      }
    }

    try {
      // Attempt to parse the response as JSON
      const jsonOutput: ChatbotResponseSchema = JSON.parse(fullResponse);
      return jsonOutput;
    } catch (jsonError) {
      console.warn("Chatbot response was not valid JSON, returning raw text:", fullResponse, jsonError);
      return fullResponse; // Return raw text if JSON parsing fails
    }

  } catch (error: any) {
    return handleApiError(error);
  }
}

export function resetChatbotSession() {
  chatInstance = null;
}


// --- Voice Chat (Live API) ---
const LIVE_API_MODEL = 'gemini-2.5-flash-native-audio-preview-12-2025';
let liveSessionPromise: Promise<any> | null = null; // Store the session promise

export async function connectLiveAudioChat(callbacks: LiveChatCallbacks, systemInstruction: string = 'You are a helpful assistant.'): Promise<any> {
  try {
    await ensureApiKeySelected(); // Live API might require a paid key
    const ai = getGeminiClient();
    liveSessionPromise = ai.live.connect({
      model: LIVE_API_MODEL,
      callbacks: callbacks,
      config: {
        responseModalities: [Modality.AUDIO],
        speechConfig: {
          voiceConfig: { prebuiltVoiceConfig: { voiceName: 'Zephyr' } },
        },
        systemInstruction: systemInstruction,
        inputAudioTranscription: {}, // Enable transcription for user input audio.
        outputAudioTranscription: {}, // Enable transcription for model output audio.
      },
    });
    return liveSessionPromise;
  } catch (error: any) {
    return handleApiError(error);
  }
}

export async function sendLiveAudioInput(pcmBlob: { data: string, mimeType: string }) {
  if (liveSessionPromise) {
    const session = await liveSessionPromise;
    session.sendRealtimeInput({ media: pcmBlob });
  } else {
    console.warn("Live session not connected.");
  }
}

export async function closeLiveAudioChat() {
  if (liveSessionPromise) {
    const session = await liveSessionPromise;
    session.close();
    liveSessionPromise = null;
  }
}