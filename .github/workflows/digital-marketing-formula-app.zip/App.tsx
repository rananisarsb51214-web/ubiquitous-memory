import React, { useState, useCallback, useEffect } from 'react';
import { FeatureCard } from './components/FeatureCard';
import { FormulaForm } from './components/FormulaForm';
import { ContentDisplay } from './components/ContentDisplay';
import { LoadingSpinner } from './components/LoadingSpinner';
import { generateMarketingContent } from './services/geminiService';
import { FeatureCardProps, FormValues, FeatureType } from './types';
import { FEATURE_CARDS } from './constants';
import { ImageGenerator } from './components/ImageGenerator';
import { ImageEditor } from './components/ImageEditor';
import { SpeechGenerator } from './components/SpeechGenerator';
import { AudioTranscriber } from './components/AudioTranscriber';
import { VideoAnalyzer } from './components/VideoAnalyzer';
import { Chatbot } from './components/Chatbot';
import { VoiceChat } from './components/VoiceChat';
import { AffiliatePromoter } from './components/AffiliatePromoter';
import { CartoonRestyle } from './components/CartoonRestyle'; // New import
import { ThemeToggle } from './components/ThemeToggle'; // New import
import { applyTheme, getInitialTheme, listenForSystemThemeChanges } from './utils/themeUtils'; // New import

function App() {
  const [selectedFeature, setSelectedFeature] = useState<FeatureCardProps | null>(null);
  const [generatedContent, setGeneratedContent] = useState<string | null>(null); // For text-based formulas
  const [isLoading, setIsLoading] = useState<boolean>(false);
  const [error, setError] = useState<string | null>(null);
  const [currentTheme, setCurrentTheme] = useState<'light' | 'dark'>(getInitialTheme());

  useEffect(() => {
    applyTheme(currentTheme); // Apply theme on initial load and theme changes
  }, [currentTheme]);

  useEffect(() => {
    // Listen for system theme changes
    const unsubscribe = listenForSystemThemeChanges(newTheme => {
      setCurrentTheme(newTheme);
      applyTheme(newTheme);
    });
    return () => unsubscribe();
  }, []);

  const handleSelectFeature = useCallback((feature: FeatureCardProps) => {
    setSelectedFeature(feature);
    setGeneratedContent(null); // Clear previous content
    setError(null); // Clear previous errors
  }, []);

  const handleSubmitFormulaForm = useCallback(async (formValues: FormValues) => {
    if (!selectedFeature || selectedFeature.featureType !== FeatureType.FORMULA) return;

    setIsLoading(true);
    setError(null);
    setGeneratedContent(null);

    try {
      const content = await generateMarketingContent(selectedFeature, formValues);
      setGeneratedContent(content);
    } catch (e: any) {
      console.error("Error generating content:", e);
      setError(e.message || "Failed to generate content. Please try again.");
    } finally {
      setIsLoading(false);
    }
  }, [selectedFeature]);

  const handleBackToFeatureSelection = useCallback(() => {
    setSelectedFeature(null);
    setGeneratedContent(null);
    setError(null);
  }, []);

  const renderFeatureComponent = () => {
    if (!selectedFeature) {
      return (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
          {FEATURE_CARDS.map((feature) => (
            <FeatureCard
              key={feature.id}
              feature={feature}
              onSelect={handleSelectFeature}
            />
          ))}
        </div>
      );
    }

    switch (selectedFeature.featureType) {
      case FeatureType.FORMULA:
        return (
          <div className="space-y-6">
            <h2 className="text-2xl sm:text-3xl font-bold text-gray-800 dark:text-gray-100 text-center mb-6">
              {selectedFeature.name}
            </h2>
            {generatedContent ? (
              <ContentDisplay
                content={generatedContent}
                onBack={() => setGeneratedContent(null)} // Allows generating new content for the same formula
                onBackToMain={handleBackToFeatureSelection} // Go back to main menu
              />
            ) : (
              <FormulaForm
                formula={selectedFeature}
                onSubmit={handleSubmitFormulaForm}
                onBack={handleBackToFeatureSelection}
                isLoading={isLoading}
                error={error}
              />
            )}
          </div>
        );
      case FeatureType.IMAGE_GEN:
        return (
          <ImageGenerator onBack={handleBackToFeatureSelection} />
        );
      case FeatureType.IMAGE_EDIT:
        return (
          <ImageEditor onBack={handleBackToFeatureSelection} />
        );
      case FeatureType.TEXT_TO_SPEECH:
        return (
          <SpeechGenerator onBack={handleBackToFeatureSelection} />
        );
      case FeatureType.AUDIO_TRANSCRIPT:
        return (
          <AudioTranscriber onBack={handleBackToFeatureSelection} />
        );
      case FeatureType.VIDEO_ANALYSIS:
        return (
          <VideoAnalyzer onBack={handleBackToFeatureSelection} />
        );
      case FeatureType.CHATBOT:
        return (
          <Chatbot onBack={handleBackToFeatureSelection} />
        );
      case FeatureType.VOICE_CHAT:
        return (
          <VoiceChat onBack={handleBackToFeatureSelection} />
        );
      case FeatureType.AFFILIATE_PROMOTION:
        return (
          <AffiliatePromoter
            feature={selectedFeature}
            onBack={handleBackToFeatureSelection}
          />
        );
      case FeatureType.CARTOON_RESTYLE: // New case
        return (
          <CartoonRestyle onBack={handleBackToFeatureSelection} />
        );
      default:
        return (
          <div className="text-center text-red-500">
            Feature not implemented yet.
            <button onClick={handleBackToFeatureSelection} className="ml-4 text-purple-600 dark:text-purple-400">
              Go Back
            </button>
          </div>
        );
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-100 to-blue-100 dark:from-gray-900 dark:to-gray-800 flex flex-col items-center p-4 sm:p-6 md:p-8">
      <header className="w-full max-w-4xl bg-white dark:bg-gray-800 shadow-lg rounded-xl p-4 sm:p-6 mb-8 flex justify-between items-center"> {/* Adjusted padding */}
        <div className="text-center flex-grow">
          <h1 className="text-2xl sm:text-3xl font-extrabold text-purple-700 dark:text-purple-400 mb-1"> {/* Adjusted text size */}
            Digital Marketing AI Studio
          </h1>
          <p className="text-md text-gray-600 dark:text-gray-300"> {/* Adjusted text size */}
            Unleash AI power for your marketing, content creation, and communication.
          </p>
        </div>
        <ThemeToggle currentTheme={currentTheme} setTheme={setCurrentTheme} />
      </header>

      <main className="w-full max-w-4xl bg-white dark:bg-gray-800 shadow-xl rounded-xl p-6 md:p-8">
        {renderFeatureComponent()}
      </main>
    </div>
  );
}

export default App;